package com.example.snakeice

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class LeaderboardActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leaderboard)  // We'll create this next

        listView = findViewById(R.id.leaderboardListView)
        loadLeaderboard()
    }

    private fun loadLeaderboard() {
        db.collection("scores")
            .orderBy("score", Query.Direction.DESCENDING)
            .limit(10)
            .get()
            .addOnSuccessListener { documents ->
                val scoresList = mutableListOf<String>()
                for (document in documents) {
                    val username = document.getString("username") ?: "Unknown"
                    val score = document.getLong("score") ?: 0
                    scoresList.add("$username: $score")
                }
                val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, scoresList)
                listView.adapter = adapter
            }
            .addOnFailureListener { /* Optional: Handle error, e.g., Toast */ }
    }
}