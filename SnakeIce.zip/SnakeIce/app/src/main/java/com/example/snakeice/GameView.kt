package com.example.snakeice

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.LinkedList
import java.util.Random
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.min

class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : SurfaceView(context, attrs, defStyleAttr), SurfaceHolder.Callback, Runnable {

    private var thread: Thread? = null
    private var running = false
    private val paint = Paint()
    private val random = Random()

    // Snake properties
    private val snake = LinkedList<Pair<Int, Int>>()  // List of (x, y) positions
    private var direction = Direction.RIGHT
    private var foodX = 0
    private var foodY = 0
    private var score = 0
    var gameOver = false
        private set

    // Callback for game over
    var onGameOver: ((Int) -> Unit)? = null  // Passes final score

    // Firestore
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    // Grid properties
    private var blockSize = 50f  // Initial block size; will be recalculated
    private var screenWidth = 0  // Logical grid width (number of blocks)
    private var screenHeight = 0  // Logical grid height (number of blocks)

    // Apple bitmap
    private var appleBitmap: Bitmap? = null

    private lateinit var gestureDetector: GestureDetector

    init {
        holder.addCallback(this)
        // Load apple image and scale it to initial blockSize
        appleBitmap = BitmapFactory.decodeResource(resources, R.drawable.apple)?.let {
            Bitmap.createScaledBitmap(it, blockSize.toInt(), blockSize.toInt(), true)
        }
        gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                if (e1 == null) return false
                val deltaX = e2.x - e1.x
                val deltaY = e2.y - e1.y
                if (abs(deltaX) > abs(deltaY)) {
                    // Horizontal swipe
                    if (deltaX > 0) changeDirection(Direction.RIGHT)
                    else changeDirection(Direction.LEFT)
                } else {
                    // Vertical swipe
                    if (deltaY > 0) changeDirection(Direction.DOWN)
                    else changeDirection(Direction.UP)
                }
                return true
            }
        })
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        recalculateGrid()
        // Rescale apple bitmap after blockSize is calculated
        appleBitmap = BitmapFactory.decodeResource(resources, R.drawable.apple)?.let {
            Bitmap.createScaledBitmap(it, blockSize.toInt(), blockSize.toInt(), true)
        }
        restart()  // Initial setup
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        recalculateGrid()
        // Rescale apple bitmap on size change
        appleBitmap = BitmapFactory.decodeResource(resources, R.drawable.apple)?.let {
            Bitmap.createScaledBitmap(it, blockSize.toInt(), blockSize.toInt(), true)
        }
    }

    private fun recalculateGrid() {
        // Calculate blockSize to fit the screen fully with integer blocks
        val minBlockSize = 40f  // Increased minimum block size for better visibility
        val minDimension = min(width.toFloat(), height.toFloat())
        blockSize = floor(minDimension.toDouble() / 15.0).toFloat().coerceAtLeast(minBlockSize)  // Changed to /15.0 for fewer blocks (larger size)
        screenWidth = (width / blockSize).toInt()
        screenHeight = (height / blockSize).toInt()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        thread?.join()
    }

    override fun run() {
        while (running) {
            if (!holder.surface.isValid) continue
            val canvas = holder.lockCanvas()
            drawGame(canvas)
            if (!gameOver) updateGame()
            holder.unlockCanvasAndPost(canvas)
            Thread.sleep(200)  // Game speed: lower = faster
        }
    }

    private fun drawGame(canvas: Canvas) {
        // Background
        canvas.drawColor(Color.BLACK)

        // Snake
        paint.color = Color.GREEN
        for (segment in snake) {
            canvas.drawRect(
                segment.first * blockSize,
                segment.second * blockSize,
                (segment.first + 1) * blockSize,
                (segment.second + 1) * blockSize,
                paint
            )
        }

        // Food (draw apple bitmap or fallback to red rectangle)
        if (foodX >= 0 && foodY >= 0) {
            if (appleBitmap != null) {
                canvas.drawBitmap(
                    appleBitmap!!,
                    foodX * blockSize,
                    foodY * blockSize,
                    null
                )
            } else {
                // Fallback if bitmap fails to load
                paint.color = Color.RED
                canvas.drawRect(
                    foodX * blockSize,
                    foodY * blockSize,
                    (foodX + 1) * blockSize,
                    (foodY + 1) * blockSize,
                    paint
                )
            }
        }

        // Score
        paint.color = Color.WHITE
        paint.textSize = 40f
        canvas.drawText("Score: $score", 20f, 50f, paint)

        if (gameOver) {
            paint.textSize = 60f
            canvas.drawText("Game Over! Score: $score", width / 4f, height / 2f, paint)
        }
    }

    private fun updateGame() {
        // Move snake
        val head = snake.first
        var newHead = when (direction) {
            Direction.UP -> Pair(head.first, head.second - 1)
            Direction.DOWN -> Pair(head.first, head.second + 1)
            Direction.LEFT -> Pair(head.first - 1, head.second)
            Direction.RIGHT -> Pair(head.first + 1, head.second)
        }

        // Check collisions
        if (newHead.first < 0 || newHead.first >= screenWidth ||
            newHead.second < 0 || newHead.second >= screenHeight ||
            snake.contains(newHead)
        ) {
            gameOver = true
            saveScoreToFirestore()
            onGameOver?.invoke(score)
            return
        }

        snake.addFirst(newHead)

        // Eat food
        if (newHead.first == foodX && newHead.second == foodY) {
            score++
            generateFood()
        } else {
            snake.removeLast()
        }
    }

    private fun generateFood() {
        if (screenWidth <= 0 || screenHeight <= 0) return  // Safety check
        foodX = random.nextInt(screenWidth)
        foodY = random.nextInt(screenHeight - 3)  // Avoid last 3 rows to prevent overlap with buttons
    }

    fun changeDirection(newDirection: Direction) {
        // Prevent reversing
        if (direction != newDirection.opposite()) {
            direction = newDirection
        }
    }

    fun restart() {
        snake.clear()
        if (screenWidth > 0 && screenHeight > 0) {
            snake.add(Pair(screenWidth / 2, screenHeight / 2))
            generateFood()
        }
        direction = Direction.RIGHT
        score = 0
        gameOver = false

        if (!running) {
            running = true
            thread = Thread(this)
            thread?.start()
        }
    }

    private fun saveScoreToFirestore() {
        val user = auth.currentUser
        if (user != null) {
            val scoreData = hashMapOf(
                "username" to user.email,
                "score" to score,
                "timestamp" to System.currentTimeMillis()
            )
            db.collection("scores")
                .add(scoreData)
                .addOnSuccessListener { /* Optional: success handling */ }
                .addOnFailureListener { /* Optional: error handling */ }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        return gestureDetector.onTouchEvent(event) || super.onTouchEvent(event)
    }

    enum class Direction {
        UP, DOWN, LEFT, RIGHT;

        fun opposite(): Direction = when (this) {
            UP -> DOWN
            DOWN -> UP
            LEFT -> RIGHT
            RIGHT -> LEFT
        }
    }
}