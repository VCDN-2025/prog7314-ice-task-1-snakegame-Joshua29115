package com.example.snakeice

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.snakeice.ui.theme.SnakeIceTheme
import com.google.firebase.auth.FirebaseAuth
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        enableEdgeToEdge()
        setContent {
            SnakeIceTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    GameScreen(
                        onLogout = {
                            auth.signOut()
                            startActivity(Intent(this@MainActivity, AuthActivity::class.java))
                            finish()
                        },
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun GameScreen(onLogout: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val gameViewState = remember { mutableStateOf<GameView?>(null) }
    var showRestart by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize()) {
        AndroidView(
            factory = {
                GameView(it).apply {
                    gameViewState.value = this
                    onGameOver = { _ ->
                        showRestart = true
                    }
                    // Ensure the view can receive focus (optional backup)
                    isFocusable = true
                    isFocusableInTouchMode = true
                    requestFocus()
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val (deltaX, deltaY) = dragAmount
                        if (abs(deltaX) > abs(deltaY)) {
                            // Horizontal swipe
                            if (deltaX > 0) gameViewState.value?.changeDirection(GameView.Direction.RIGHT)
                            else gameViewState.value?.changeDirection(GameView.Direction.LEFT)
                        } else {
                            // Vertical swipe
                            if (deltaY > 0) gameViewState.value?.changeDirection(GameView.Direction.DOWN)
                            else gameViewState.value?.changeDirection(GameView.Direction.UP)
                        }
                    }
                }
        )

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(onClick = { gameViewState.value?.changeDirection(GameView.Direction.UP) }) {
                    Text("Up")
                }
                Button(onClick = { gameViewState.value?.changeDirection(GameView.Direction.DOWN) }) {
                    Text("Down")
                }
                Button(onClick = { gameViewState.value?.changeDirection(GameView.Direction.LEFT) }) {
                    Text("Left")
                }
                Button(onClick = { gameViewState.value?.changeDirection(GameView.Direction.RIGHT) }) {
                    Text("Right")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(onClick = onLogout) {
                    Text("Logout")
                }
                Button(onClick = {
                    context.startActivity(Intent(context, LeaderboardActivity::class.java))
                }) {
                    Text("Leaderboard")
                }
            }
        }

        // Restart button overlay when game over
        if (showRestart) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Button(
                    onClick = {
                        gameViewState.value?.restart()
                        showRestart = false
                    }
                ) {
                    Text("Restart Game")
                }
            }
        }
    }
}